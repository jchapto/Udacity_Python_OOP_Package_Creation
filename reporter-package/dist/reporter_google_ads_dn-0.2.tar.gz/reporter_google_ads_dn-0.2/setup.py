from setuptools import setup

setup(name="reporter_google_ads_dn",
 version="0.2",
 description="Google ads reporter",
 packages=['reporter_google_ads_dn'],
 zip_safe=False)
